pub mod types;
pub mod lucet;
pub mod utils;

use crate::{loaders, config};
use self::types::*;
use self::lucet::*;
use config::Config;
use yaxpeax_core::memory::repr::process::ModuleData;

pub fn load_program(config: &Config) -> VwModule {
    return load_lucet_program(config)
}

pub trait Loadable {
    fn is_valid_func_name(&self, name: &String) -> bool;
    fn get_func_signatures(&self, program: &ModuleData) -> VwFuncInfo;
    fn get_plt_funcs(&self, binpath: &str) -> Option<Vec<(u64, String)>>;
}

impl Loadable for ExecutableType {
    fn is_valid_func_name(&self, name: &String) -> bool {
        match self {
            ExecutableType::Lucet => is_valid_lucet_func_name(name),
            ExecutableType::Wasmtime => is_valid_wasmtime_func_name(name),
        }
    }

    fn get_func_signatures(&self, program: &ModuleData) -> VwFuncInfo {
        match self {
            ExecutableType::Lucet => get_lucet_func_signatures(program),
            ExecutableType::Wasmtime => get_wasmtime_func_signatures(program),
        }
    }

    fn get_plt_funcs(&self, binpath: &str) -> Option<Vec<(u64, String)>> {
        match self {
            ExecutableType::Lucet => lucet_get_plt_funcs(binpath),
            ExecutableType::Wasmtime => wasmtime_get_plt_funcs(binpath),
        }
    }
}
